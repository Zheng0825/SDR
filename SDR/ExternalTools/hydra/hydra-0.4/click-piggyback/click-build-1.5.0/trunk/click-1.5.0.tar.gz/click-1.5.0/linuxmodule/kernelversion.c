/*
 * kernelversion.c -- make sure we get a Linux module kernel version variable
 * Robert Morris, Eddie Kohler
 *
 * Copyright (c) 1999 Massachusetts Institute of Technology
 * Copyright (c) 2005 Regents of the University of California
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, subject to the conditions
 * listed in the Click LICENSE file. These conditions include: you must
 * preserve this copyright notice, and you cannot mention the copyright
 * holders in advertising related to the Software without their permission.
 * The Software is provided WITHOUT ANY WARRANTY, EXPRESS OR IMPLIED. This
 * notice is a summary of the Click LICENSE file; the license in that file is
 * legally binding.
 */

/*
 * Use C, because g++ seems to ignore the version declaration, which
 * ends up looking like
 *  const char __module_kernel_version[] __attribute__((section(".modinfo"))) =
 *  "kernel_version=" "2.2.6" ;
 */

#include <click/config.h>
#include <linux/version.h>
#include <linux/module.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 52)
# define CLICK_INT_MODULE_PARAM(param)	MODULE_PARM(param, "i")
#else
# define CLICK_INT_MODULE_PARAM(param)	module_param(param, int, 0)
#endif

static int accessible = 1;
CLICK_INT_MODULE_PARAM(accessible);
MODULE_PARM_DESC(accessible, "make /proc/click world-readable [1]");

#if __MTCLICK__
static int threads = 1;
CLICK_INT_MODULE_PARAM(threads);
MODULE_PARM_DESC(threads, "number of Click threads per router [1]");
#endif

#ifdef MODULE_LICENSE
MODULE_LICENSE("Dual BSD/GPL");
#endif

static int greedy = 0;
CLICK_INT_MODULE_PARAM(greedy);
MODULE_PARM_DESC(greedy, "Click takes a whole CPU [0]");

int
click_accessible(void)
{
  return accessible;
}

#if __MTCLICK__
int
click_threads(void)
{
  return threads;
}
#endif

int
click_greedy(void)
{
    return greedy;
}
