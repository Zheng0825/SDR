#define BIM_ESC 0xac
#define BIM_ESC_ESC 0xB2
#define BIM_ESC_START 0xc6
#define BIM_ESC_END 0x87
