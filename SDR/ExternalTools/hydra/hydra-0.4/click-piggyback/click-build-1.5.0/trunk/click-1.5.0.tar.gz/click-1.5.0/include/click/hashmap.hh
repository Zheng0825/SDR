#ifndef CLICK_HASHMAP_HH
#define CLICK_HASHMAP_HH

// This file is here for compatibility only.
#include <click/bighashmap.hh>

#endif
